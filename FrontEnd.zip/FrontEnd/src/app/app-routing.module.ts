import {NgModule} from '@angular/core';
import {RouterModule , Routes} from '@angular/router';
import { AuthorisationErrorComponent } from './shared/authorisation-error/authorisation-error.component';
import { AddCardComponent } from './customer/customer-home/customer-details/add-card/add-card.component';

const routes:Routes=[
    {path:'error',component:AuthorisationErrorComponent},
    {path:'',redirectTo:'/applicationHome/login',pathMatch:'full'},
    { path: 'add-card', component: AddCardComponent },
]

@NgModule(
    {
        declarations:[],
        imports:[
            RouterModule.forRoot(routes)
        ],
        exports:[RouterModule]
    }
)
export class AppRoutingModule{

}