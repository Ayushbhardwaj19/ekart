import { NgModule } from "@angular/core";
import { CustomerCartComponent } from "./customer-cart.component";
import { CheckoutComponent } from "./checkout/checkout.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { NgxPaginationModule } from "ngx-pagination";
import { HttpClientModule } from "@angular/common/http";
import { CustomerRoutingModule } from "../../customer-routing.module";

@NgModule({
    declarations: [
        
        CustomerCartComponent,
        CheckoutComponent,
    ],
    imports: [
        NgxPaginationModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        CustomerRoutingModule
    ],
    providers: [
        
    ],
    exports: []
})
export class CustomerCartModule{

}