import {Component} from "@angular/core"
import { Cart } from "src/app/shared/models/cart"
import { CustomerCartService } from "../customer-cart.service"
import { Customer } from "src/app/shared/models/customer"
import { CustomerSharedService } from "../../customer-shared-service"
import { Card } from "../../customer-details/add-card/Card"
import { Router } from "@angular/router"
import { HttpClient } from "@angular/common/http"



@Component({
    selector: 'app-checkout',
    templateUrl : './checkout.component.html', 
    styleUrls : ['./checkout.component.css']
})
export class CheckoutComponent{
    cartList: Cart[] = []

    loggedInCustomer: any;
    totalAmountToBePaid!:number
    addresses!:string
    addressesText = ""
    personName = ""




    // properties for orders

    // orderId = 1
    // address = this.addressesText
    // buyerId = 1
    // card_no = 7838397347
    // deliverDate = "16/9/22"
    // estimatedDeliverDate = "16/9/22"
    // orderDate = "16/9/22"
    // productId = this.cartList[0].product.productId
    // quantity = this.cartList[0].quantity
    // sellerId = this.cartList[0].product.sellerEmailId
    // status = "on the way"


    cards!: Card[];
    cardNumbers:number[]
    cardNumber:string = " "


    show:boolean = false
    displayText!:string



    ngOnInit(): void {
        this.loggedInCustomer = JSON.parse(sessionStorage.getItem("customer"));
        this.customerCartService.getCustomerCart(this.loggedInCustomer.emailId).subscribe(
            cart => {
                this.cartList = cart;
                console.log(this.cartList)
                sessionStorage.setItem("cart", JSON.stringify(this.cartList));
                this.customerSharedService.updateCartList(this.cartList)
            }, err => {
            }
        )    
    }

    ngAfterViewInit(): void{
        
    }

    constructor(private customerCartService: CustomerCartService, private customerSharedService: CustomerSharedService, private router: Router, private http: HttpClient) {
    }

    //1 total amount
    // add orders to db
    //delete cart items from db


    calculateTotalBill(){
        let x:number = 0
        for(let y of this.cartList){
            x = x +  y.quantity * y.product.price
        }
        this.totalAmountToBePaid = x
    }  

    getShippingAddress(){
        this.loggedInCustomer = JSON.parse(sessionStorage.getItem("customer"));
        this.addresses = this.loggedInCustomer.addresses;
        //for (let x of this.addresses){
        //this.addressesText.push(x.addressLine1 + x.addressLine2 + x.city + x.state +  x.pin + x.contactNumber)  
        //}


        this.addressesText = this.addresses[0].addressLine1 + " " + this.addresses[0].addressLine2 + " " + this.addresses[0].city + " " + this.addresses[0].state + " "+  this.addresses[0].pin + " " + this.addresses[0].contactNumber

        //console.log(this.addresses)
        console.log(this.addressesText)

    }

    getName(){
        this.loggedInCustomer = JSON.parse(sessionStorage.getItem("customer"));
        this.personName = this.loggedInCustomer.name
        console.log(this.loggedInCustomer)
    }

    getCards() {
        this.http.get<any>(`http://localhost:9111/cardInfo/view?customerEmail=${this.loggedInCustomer.emailId}`).subscribe((result) => {
          console.log(result[0].cardNumber);
          this.cardNumber = result[0].cardNumber
          this.cards = JSON.parse(JSON.stringify(result));
        });

        // for (let x of this.cards){
        //     this.cardNumbers.push(x.cardNumber)
        // }
        // console.log(this.cardNumbers)
        // this.cardNumber = this.cardNumbers[0]
        // console.log(this.cardNumber)
        
      }

      generateFinalString(){
        this.show = true;
        //this.displayText = `Congratulations! your order has been placed and will be shipped to the address = ${this.addressesText} very soon!`
      }




}

