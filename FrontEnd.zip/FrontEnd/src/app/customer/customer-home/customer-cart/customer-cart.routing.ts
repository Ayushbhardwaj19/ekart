import { NgModule } from '@angular/core';
import { Routes } from '@angular/router';
import { CheckoutComponent } from './checkout/checkout.component';
import { RouterModule } from '@angular/router';

const routes2:Routes = [
    {path: "checkout", component:CheckoutComponent}
]

@NgModule({
  imports: [RouterModule.forChild(routes2)],
  exports: [RouterModule]
})
export class CustomerCartRoutingModule{

}