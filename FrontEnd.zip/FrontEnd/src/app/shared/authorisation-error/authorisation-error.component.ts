import { Component } from "@angular/core";



@Component({
    selector:'authorisation-error',
    templateUrl:'./authorisation-error.component.html'
})
export class AuthorisationErrorComponent{

}