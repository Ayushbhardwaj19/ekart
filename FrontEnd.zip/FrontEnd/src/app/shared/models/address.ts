

export class Address{
    addressId:number;
    contactNumber:string;
    addressLine1:string;
    addressLine2:string;
    city:string;
    state:string;
    pin:string;
}